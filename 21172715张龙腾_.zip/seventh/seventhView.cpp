
// seventhView.cpp : implementation of the CseventhView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "seventh.h"
#endif

#include "seventhDoc.h"
#include "seventhView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CPoint ptc[20];
CPoint Input[20];
CPoint Output[20];
int n = 0;
int num = 0;
double PI = 3.1415;
double con[4][4];
// CseventhView

IMPLEMENT_DYNCREATE(CseventhView, CView)

BEGIN_MESSAGE_MAP(CseventhView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CseventhView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_TWO, &CseventhView::OnTwo)
	ON_COMMAND(ID_THEONE, &CseventhView::OnTheone)
	ON_COMMAND(ID_THREE, &CseventhView::OnThree)
	ON_WM_MOUSEHWHEEL()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()

// CseventhView construction/destruction

CseventhView::CseventhView() noexcept
{
	// TODO: add construction code here

}

CseventhView::~CseventhView()
{
}

BOOL CseventhView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CseventhView drawing

void CseventhView::OnDraw(CDC* /*pDC*/)
{
	CseventhDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}


// CseventhView printing


void CseventhView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CseventhView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CseventhView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CseventhView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CseventhView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CseventhView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CseventhView diagnostics

#ifdef _DEBUG
void CseventhView::AssertValid() const
{
	CView::AssertValid();
}

void CseventhView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CseventhDoc* CseventhView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CseventhDoc)));
	return (CseventhDoc*)m_pDocument;
}
#endif //_DEBUG


// CseventhView message handlers


void CseventhView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);
	ptc[n] = point;
	if (n != 0)
	{
		dc.MoveTo(ptc[n - 1]);
		dc.LineTo(ptc[n]);
	}
	n = n + 1;
	CView::OnLButtonDown(nFlags, point);
	CView::OnLButtonDown(nFlags, point);
}


void CseventhView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	Input[0] = ptc[0];
	Input[1] = ptc[0];
	num = 2;
	for (int ki = 0; ki < n; ki++)
		Input[num++] = ptc[ki];
	Input[num++] = ptc[n - 1];
	Input[num++] = ptc[n - 1];
	OnB();
	CView::OnLButtonDblClk(nFlags, point);
}


void CseventhView::OnTwo()
{
	// TODO: Add your command handler code here
	xiangfan();

}


void CseventhView::OnTheone()
{
	ClearScreen();

	// TODO: Add your command handler code here
}


void CseventhView::OnThree()
{
	// TODO: Add your command handler code here
	OnThe();

}

void CseventhView::OnB()
{
	if (num < 4)return;
	CClientDC dc(this);
	for (int i = 0; i < num - 3; i++) {
		double p0y = Input[0 + i].y;
		double p1y = Input[1 + i].y;
		double p2y = Input[2 + i].y;
		double p3y = Input[3 + i].y;
		double p0x = Input[0 + i].x;
		double p1x = Input[1 + i].x;
		double p2x = Input[2 + i].x;
		double p3x = Input[3 + i].x;
		for (double u = 0; u < 1; u += 0.001) {
			int x = ((1 - u) * (1 - u) * (1 - u) * p0x + (3 * u * u * u - 6 * u * u + 4) * p1x + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2x + u * u * u * p3x) / 6;
			int y = ((1 - u) * (1 - u) * (1 - u) * p0y + (3 * u * u * u - 6 * u * u + 4) * p1y + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2y + u * u * u * p3y) / 6;
			if (i % 3 == 0)
				dc.SetPixel(x, y, RGB(255, 0, 0));
			if (i % 3 == 1)
				dc.SetPixel(x, y, RGB(0, 255, 0));
			if (i % 3 == 2)
				dc.SetPixel(x, y, RGB(0, 0, 255));
		}
	}
}

void CseventhView::OnF()
{
	if (num < 4)return;
	CClientDC dc(this);
	for (int i = 0; i < num - 3; i++) {
		double p0y = Output[0 + i].y;
		double p1y = Output[1 + i].y;
		double p2y = Output[2 + i].y;
		double p3y = Output[3 + i].y;
		double p0x = Output[0 + i].x;
		double p1x = Output[1 + i].x;
		double p2x = Output[2 + i].x;
		double p3x = Output[3 + i].x;
		for (double u = 0; u < 1; u += 0.001) {
			int x = ((1 - u) * (1 - u) * (1 - u) * p0x + (3 * u * u * u - 6 * u * u + 4) * p1x + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2x + u * u * u * p3x) / 6;
			int y = ((1 - u) * (1 - u) * (1 - u) * p0y + (3 * u * u * u - 6 * u * u + 4) * p1y + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2y + u * u * u * p3y) / 6;
			if (i % 3 == 0)
				dc.SetPixel(x, y, RGB(255, 0, 0));
			if (i % 3 == 1)
				dc.SetPixel(x, y, RGB(0, 255, 0));
			if (i % 3 == 2)
				dc.SetPixel(x, y, RGB(0, 0, 255));
		}
	}
}

void CseventhView::xiangfan()
{
	int x1 = ptc[0].x;
	for (int i = 0; i < num; i++)
	{
		Output[i].x = 2 * x1 - Input[i].x;
		Output[i].y = Input[i].y;
	}
	OnF();
}

void CseventhView::OnThe()
{
	CClientDC dc(this);
	CRect rect;
	GetClientRect(&rect);
	CBrush brush(RGB(255, 255, 255));
	dc.FillRect(rect, &brush);
	_3Point tmp[100];
	for (int i = 0; i < num; i++) {
		tmp[i] = _3Point(Input[i].x - Input[0].x, Input[i].y - Input[0].y, 0);
	}
	if (num < 4)return;
	for (int w = 0; w < 36; w++) {
		for (int i = 0; i < num - 3; i++) {
			for (int j = 0; j < 4; j++) {
				tmp[i + j].x = (Input[i + j].x - Input[0].x) * cos(w * PI / 18);
				tmp[i + j].z = -(Input[i + j].x - Input[0].x) * sin(w * PI / 18);
				tmp[i + j].y = Input[i + j].y - Input[0].y;
			}
			double p0y = tmp[(0 + i)].y;
			double p1y = tmp[(1 + i)].y;
			double p2y = tmp[(2 + i)].y;
			double p3y = tmp[(3 + i)].y;
			double p0x = tmp[(0 + i)].x;
			double p1x = tmp[(1 + i)].x;
			double p2x = tmp[(2 + i)].x;
			double p3x = tmp[(3 + i)].x;
			double p0z = tmp[(0 + i)].z;
			double p1z = tmp[(1 + i)].z;
			double p2z = tmp[(2 + i)].z;
			double p3z = tmp[(3 + i)].z;
			for (double u = 0; u < 1; u += 0.001) {
				int x = ((1 - u) * (1 - u) * (1 - u) * p0x + (3 * u * u * u - 6 * u * u + 4) * p1x + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2x + u * u * u * p3x) / 6;
				int y = ((1 - u) * (1 - u) * (1 - u) * p0y + (3 * u * u * u - 6 * u * u + 4) * p1y + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2y + u * u * u * p3y) / 6;
				int z = ((1 - u) * (1 - u) * (1 - u) * p0z + (3 * u * u * u - 6 * u * u + 4) * p1z + (-3 * u * u * u + 3 * u * u + 3 * u + 1) * p2z + u * u * u * p3z) / 6;
				dc.SetPixel(Tran322(Input[0].x, Input[0].y, _3Point(x, -y, z)).x, Tran322(Input[0].x, Input[0].y, _3Point(x, -y, z)).y, RGB(255 * (i % 3 == 0), 255 * (i % 3 == 1), 255 * (i % 3 == 2)));
			}
		}
	}
}

void CseventhView::ClearScreen()
{
	CClientDC dc(this);
	CRect window;
	GetClientRect(window);
	dc.SelectStockObject(WHITE_PEN);
	dc.SelectStockObject(WHITE_BRUSH);
	dc.Rectangle(window);
}

void CseventhView::DrawVectorGraph(int radius,int k)
{
	CDC* pDC = GetDC();
	CRect rect;
	this->GetClientRect(rect);
	int x0 = rect.right / 2;
	int y0 = rect.bottom / 2;
	double pi = 3.1415926;
	double a = 0;
	int x1, y1;
	int x = 0, y = 0;
	CPen MyPen;
	MyPen.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
	pDC->SelectObject(&MyPen);
	for (a = 0; a < pi * 2; a += (pi / 100)) {
		double r = radius * sin(k * a);

		x = (int)(r * cos(a) + r * sin(a)) * pow(-1, x);
		y = (int)(r * sin(a) - r * cos(a)) * pow(-1, y);
		MyPen.DeleteObject();
		MyPen.CreatePen(PS_SOLID, 1, RGB(255, abs(x) % 255, abs(y) % 255));
		pDC->SelectObject(&MyPen);
		x = x + x0; y = y0 - y;
		if (a != 0)
		{
			pDC->MoveTo(x1, y1);
			pDC->LineTo(x, y);
		}
		x1 = x; y1 = y;
	}
	MyPen.DeleteObject();
}

CPoint CseventhView::Tran322(int CenterX, int CenterY, _3Point a)
{
	CPoint temp;
	temp.x = CenterX + a.x - a.z * cos(PI / 4) / 2;
	temp.y = CenterY - a.y + a.z * cos(PI / 4) / 2;
	return temp;
	//return CPoint();
}


void CseventhView::OnMouseHWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// This feature requires Windows Vista or greater.
	// The symbol _WIN32_WINNT must be >= 0x0600.
	// TODO: Add your message handler code here and/or call default
	//DrawVectorGraph()
	//WriteConsoleOutput()
	CView::OnMouseHWheel(nFlags, zDelta, pt);
}


BOOL CseventhView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: Add your message handler code here and/or call default
	ClearScreen();
	int delta = abs(zDelta) / zDelta;
	radius += delta * 2.5;
	k += delta;
	DrawVectorGraph(radius, k);
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}
