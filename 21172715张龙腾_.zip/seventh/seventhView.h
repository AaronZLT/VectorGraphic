
// seventhView.h : interface of the CseventhView class
//

#pragma once

class _3Point {
public:
	int x, y, z;
	_3Point(int x, int y, int z) {
		this->x = x;
		this->y = y;
		this->z = z;
	}
	_3Point() {
		this->x = this->y = this->z = 0;
	}
};


class CseventhView : public CView
{
protected: // create from serialization only
	CseventhView() noexcept;
	DECLARE_DYNCREATE(CseventhView)

// Attributes
public:
	CseventhDoc* GetDocument() const;

// Operations
public:
	int radius = 200;
	int k = 30;
	void OnB();
	void OnF();
	void xiangfan();
	void OnThe();
	void ClearScreen();
	void DrawVectorGraph(int,int);
	CPoint Tran322(int CenterX, int CenterY, _3Point a);
// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CseventhView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnTwo();
	afx_msg void OnTheone();
	afx_msg void OnThree();
	afx_msg void OnMouseHWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
};

#ifndef _DEBUG  // debug version in seventhView.cpp
inline CseventhDoc* CseventhView::GetDocument() const
   { return reinterpret_cast<CseventhDoc*>(m_pDocument); }
#endif

